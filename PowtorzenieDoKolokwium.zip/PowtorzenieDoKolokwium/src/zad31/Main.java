package zad31;

public class Main {

    public static void checkAge(int age){
        if(age<18){
            throw new IllegalArgumentException("Nie masz 18 lat");
        }
        else if(age>=18){
            System.out.println("Zweryfikowano");
        }
    }

    public static void main(String[] args) {
        checkAge(18);
        try{
            checkAge(0);
        }catch(IllegalArgumentException e){
            System.out.println(e.getMessage());
        }
        checkAge(18);
    }
}
