package zad20;

import java.time.LocalDate;
import java.util.ArrayList;
import java.sql.Date;
import java.util.Collection;
import java.util.Collections;

public class Main {
    public static void main(String[] args) {
        ArrayList<Client> c = new ArrayList<>();

        c.add(new Client("Andrzej", 1,Date.valueOf("2000-03-12")));
        c.add(new Client("Maciek", 1,Date.valueOf("2001-03-19")));
        c.add(new Client("Olaf", 1,Date.valueOf("2002-02-12")));
        c.add(new Client("Wincent", 1,Date.valueOf("2003-05-12")));
        c.add(new Client("Eustachy", 1,Date.valueOf("2004-06-12")));

        System.out.println(c);
        Collections.sort(c);
        System.out.println(c);
    }
}
