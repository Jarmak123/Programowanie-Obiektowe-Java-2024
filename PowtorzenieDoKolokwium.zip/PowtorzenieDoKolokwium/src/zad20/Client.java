package zad20;

import java.sql.Date;

public class Client implements Comparable<Client>{
    String name;
    int clientNUmber;
    Date lastLogin;

    public Client(String name, int clientNUmber, Date lastLogin) {
        this.name = name;
        this.clientNUmber = clientNUmber;
        this.lastLogin = lastLogin;
    }

    @Override
    public String toString() {
        return "Client{" +
                "name='" + name + '\'' +
                ", clientNUmber=" + clientNUmber +
                ", lastLogin=" + lastLogin +
                '\n';
    }

    @Override
    public int compareTo(Client o) {
        return this.lastLogin.compareTo(o.lastLogin);
    }
}
