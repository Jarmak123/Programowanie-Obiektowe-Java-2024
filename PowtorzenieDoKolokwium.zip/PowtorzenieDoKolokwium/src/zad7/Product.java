package zad7;

public class Product {
    static int numberOfProducts=0;
    static final int MAX_PRODUCTS=10;

    public static void addProduct() {
        numberOfProducts++;
        if(numberOfProducts>MAX_PRODUCTS)
        {
            throw new IllegalStateException("U cant do that mf");
        }
    }
}
