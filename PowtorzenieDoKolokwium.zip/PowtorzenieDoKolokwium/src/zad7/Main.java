package zad7;

public class Main {
    public static void main(String[] args) {
        System.out.println(Product.numberOfProducts);

        Product.addProduct();
        Product.addProduct();
        Product.addProduct();

        System.out.println(Product.numberOfProducts);

        for(int i=Product.numberOfProducts; i<Product.MAX_PRODUCTS+3; i++){
            Product.addProduct();
        }
        //System.out.println(Product.numberOfProducts);
    }
}
