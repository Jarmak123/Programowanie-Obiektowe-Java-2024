package zad4;

public class Main {
    public static StringBuilder reverseString(StringBuilder sb)
    {
        StringBuilder nw = new StringBuilder();

        for(int i=sb.length()-1; i>=0; i--)
        {
            nw.append(sb.charAt(i));
        }

        return nw;
    }

    public static void main(String[] args) {
        StringBuilder a = new StringBuilder("Kapitan Bomba");
        System.out.println(a);

        System.out.println(reverseString(a));
    }
}
