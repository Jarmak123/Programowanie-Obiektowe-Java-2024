package zad16;

public class Bitmap extends ComputerGraphic{
    @Override
    void loadFile() {
        System.out.println("Wczytano bitmape");
    }

    @Override
    void saveFile() {
        System.out.println("Zapisano bitmape");
    }
}
