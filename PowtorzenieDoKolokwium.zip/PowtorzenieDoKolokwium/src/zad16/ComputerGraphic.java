package zad16;

public abstract class ComputerGraphic {
    int width;
    int height;
    String filename;

    abstract void loadFile();
    abstract void saveFile();
}
