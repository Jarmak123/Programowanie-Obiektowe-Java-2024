package zad16;

public class Vector extends ComputerGraphic{
    @Override
    void loadFile() {
        System.out.println("Wczytano wektor");
    }

    @Override
    void saveFile() {
        System.out.println("Zapisano wektor");
    }
}
