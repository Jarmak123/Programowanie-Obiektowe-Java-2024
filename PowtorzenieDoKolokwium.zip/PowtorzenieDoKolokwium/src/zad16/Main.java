package zad16;

public class Main {
    public static void main(String[] args) {
        Bitmap bmp = new Bitmap();
        Vector v = new Vector();

        bmp.saveFile();
        bmp.loadFile();

        v.saveFile();
        v.loadFile();
    }
}
