package zad28;

public class AuthenticationTest {
    public static void main(String[] args) {
        String adminLogin = "admin";
        String adminPassword = "admin";
        String userLogin = "user";
        String password = "user";


    }
}
