package zad8;

import java.util.Arrays;
import java.util.Objects;

public class Result {
    private String firstName;
    private String lastName;
    int[] results;

    public Result(String firstName, String lastName, int n) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.results = new int[n];
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int[] getResults() {
        return results;
    }

    public void setResults(int[] results) {
        this.results = results;
    }

    public void addResult(int index, int result){
        results[index]=result;
    }

    public int averageResult(){
        int sum=0;
        for(int i=0; i<results.length;i++)
        {
            sum=sum+results[i];
        }

        return sum/results.length;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Result result = (Result) o;
        return Objects.equals(firstName, result.firstName) && Objects.equals(lastName, result.lastName) && Objects.deepEquals(results, result.results);
    }

    @Override
    public int hashCode() {
        return Objects.hash(firstName, lastName, Arrays.hashCode(results));
    }

    @Override
    public String toString() {
        return "Result{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", results=" + Arrays.toString(results) +
                '}';
    }
}
