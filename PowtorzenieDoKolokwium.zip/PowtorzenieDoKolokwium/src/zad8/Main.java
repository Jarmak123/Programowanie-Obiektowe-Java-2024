package zad8;

public class Main {
    public static void main(String[] args) {
        Result wynik = new Result("Jacek", "Kutowski",3);
        Result wynik1 = new Result("Justyśka", "Justa",4);

        wynik.addResult(0,4);
        wynik.addResult(1,5);
        wynik.addResult(2,4);

        wynik1.addResult(0,2);
        wynik1.addResult(1,1);
        wynik1.addResult(2,3);
        wynik1.addResult(3,3);

        System.out.println(wynik.toString());
        System.out.println(wynik.averageResult());

        System.out.println(wynik1.toString());
        System.out.println(wynik1.averageResult());



    }
}
