package zad29;

public class TestDataProcessor {
    public static void main(String[] args) {
        TestProcessor tp = new TestProcessor();
        NumberProcessor np = new NumberProcessor();

        System.out.println(tp.processData("Kapitan Bomba"));
        System.out.println(tp.isValid("Kapitan Bomba"));

        System.out.println(np.processData("3218907"));
        System.out.println(np.isValid("3218907"));
    }
}
