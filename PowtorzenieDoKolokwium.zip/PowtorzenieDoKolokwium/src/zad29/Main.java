package zad29;

public class Main {
    public static void main(String[] args) {
        for(int i=13; i>=0;i--)
        {
            System.out.println(i);
        }
    }
}
