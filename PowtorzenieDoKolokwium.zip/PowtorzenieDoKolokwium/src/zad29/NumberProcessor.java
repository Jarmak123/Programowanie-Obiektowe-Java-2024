package zad29;

public class NumberProcessor implements DataProcessor{
    @Override
    public String processData(String data) {
        return "Porocessed: "+data;
    }

    @Override
    public boolean isValid(String data) {
        for(int i=0; i<data.length(); i++){
            if(Character.isDigit(data.charAt(i))){
                return false;
            }
        }
        return true;
    }
}
