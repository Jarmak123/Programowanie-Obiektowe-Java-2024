package zad29;

public class TestProcessor implements DataProcessor{
    @Override
    public String processData(String data) {
        String ns = "";
        for(int i=data.length()-1; i>=0; i--)
        {
            ns+=data.charAt(i);
        }
        return ns;
    }

    @Override
    public boolean isValid(String data) {
        if(data.isEmpty() || data==null)
        {
            return false;
        }
        return true;
    }
}
