package zad34;

public class Main {
    public static void main(String[] args) {
        Box<String> sbox = new Box<>();

        sbox.set("siema");
        System.out.println(sbox.get());
    }
}
