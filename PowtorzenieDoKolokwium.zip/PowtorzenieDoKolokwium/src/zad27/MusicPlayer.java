package zad27;

public interface MusicPlayer {
    void turnOn();
    void turnOff();
    void nextTrack();
}
