package zad27;

public class Radio implements MusicPlayer{
    @Override
    public void turnOn() {
        System.out.println("Włączyłeś radio");
    }

    @Override
    public void turnOff() {
        System.out.println("Wyłączyłeś radio");
    }

    @Override
    public void nextTrack() {
        System.out.println("Zmieniłeś utwór");
    }
}
