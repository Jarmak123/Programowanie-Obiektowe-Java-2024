package zad3;

public class Main {
    public static String reversedFirstLast(String n)
    {
        String nw = "";
        nw=nw+n.charAt(n.length()-1);
        for(int i=1; i<n.length()-1; i++)
        {
            nw=nw+n.charAt(i);
        }
        nw=nw+n.charAt(0);

        return nw;

    }

    public static void main(String[] args) {
        System.out.println("Kapitan bomba");
        System.out.println(reversedFirstLast("Kapitan Bomba"));

    }
}
