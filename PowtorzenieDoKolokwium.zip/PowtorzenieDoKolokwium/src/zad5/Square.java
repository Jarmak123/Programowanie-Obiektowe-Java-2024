package zad5;

public class Square {
    int side;

    public Square(int side) {
        this.side = side;
    }

    public Square() {
        this(1);
    }
}
