package zad26;

public interface MyComparator {
    int compare(int a, int b);

}
