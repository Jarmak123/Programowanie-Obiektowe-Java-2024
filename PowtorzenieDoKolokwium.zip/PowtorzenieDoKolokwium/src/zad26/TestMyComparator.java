package zad26;

public class TestMyComparator implements MyComparator{
    @Override
    public int compare(int a, int b) {
        if(a<b){
            return -1;
        }
        else if(a>b){
            return 1;
        }
        else{
            return 0;
        }
    }

    public static void main(String[] args) {
        TestMyComparator comp = new TestMyComparator();

        System.out.println(comp.compare(3,5));
        System.out.println(comp.compare(5,5));
        System.out.println(comp.compare(3,1));
    }
}
