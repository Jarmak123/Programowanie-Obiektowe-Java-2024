package zad9;

public class Main {
    public static void main(String[] args) {
        Vehicle vh = new Vehicle("Mazda","3",2005);
        Car car = new Car("Fiat","Duplo",2003,2);
        Motorcycle mt = new Motorcycle("Suzuki","Kawasaki",2012, 125);

        System.out.println(vh.toString());
        System.out.println(car.toString());
        System.out.println(mt.toString());
    }
}
