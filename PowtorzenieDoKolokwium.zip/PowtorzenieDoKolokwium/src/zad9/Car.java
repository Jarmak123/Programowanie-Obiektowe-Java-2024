package zad9;

public class Car extends Vehicle{
    int numberOfDoors;

    public Car(String brand, String model, int yearOfProduction, int numberOfDoors) {
        super(brand, model, yearOfProduction);
        this.numberOfDoors = numberOfDoors;
    }

    public int getNumberOfDoors() {
        return numberOfDoors;
    }

    public void setNumberOfDoors(int numberOfDoors) {
        this.numberOfDoors = numberOfDoors;
    }

    @Override
    public String toString() {
        return super.toString() + "NumberOfDoors: " + numberOfDoors;
    }
}
