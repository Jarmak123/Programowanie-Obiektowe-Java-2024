package zad39;

public class Triple<T> {
}
