package zad30;

public interface AdvancedPowerControl extends PowerControl{
    void setPowerSavingMode();
}
