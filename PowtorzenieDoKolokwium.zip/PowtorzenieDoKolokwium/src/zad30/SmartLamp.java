package zad30;

public class SmartLamp implements AdvancedPowerControl{
    @Override
    public void setPowerSavingMode() {
        System.out.println("Power saving mode is enabled");
    }

    @Override
    public void turnOn() {
        System.out.println("Lamp is on");
    }
}
