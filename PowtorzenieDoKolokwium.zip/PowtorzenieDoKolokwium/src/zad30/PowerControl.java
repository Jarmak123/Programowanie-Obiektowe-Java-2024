package zad30;

public interface PowerControl{
    void turnOn();
}
