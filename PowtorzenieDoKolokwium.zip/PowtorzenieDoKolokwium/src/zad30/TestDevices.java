package zad30;

public class TestDevices {
    public static void main(String[] args) {
        SmartLamp sl = new SmartLamp();

        sl.turnOn();
        sl.setPowerSavingMode();
    }

}
