package zad40;

public class StandardowyPrinter implements Printer{
    @Override
    public void drukuj(String tekst) {
        System.out.println("Wydrukowano 1x karte papieru z napisem: "+tekst);
    }

}
