package zad40;

public interface Printer {
    public void drukuj(String tekst);
}
