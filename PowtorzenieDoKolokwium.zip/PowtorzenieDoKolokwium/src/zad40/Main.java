package zad40;


public class Main {
    public static void main(String[] args) {
        Biuro br = new Biuro(new StandardowyPrinter());

        br.drukujDokument("kleks");
    }
}
