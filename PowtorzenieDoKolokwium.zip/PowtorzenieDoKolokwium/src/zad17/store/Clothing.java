package zad17.store;

public class Clothing extends Product{
    @Override
    public double getPrice() {
        return 59.99;
    }
}
