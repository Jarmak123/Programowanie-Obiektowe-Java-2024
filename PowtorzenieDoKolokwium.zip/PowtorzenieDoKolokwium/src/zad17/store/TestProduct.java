package zad17.store;

public class TestProduct {
    public static void main(String[] args) {
        Product[] products = new Product[10];

        for(int i=0; i<10; i++)
        {
            if(i>4)
            {
                products[i]= new Book();
            }
            else
            {
                products[i]= new Clothing();
            }
        }

        for(int i=0; i<10; i++)
        {
            System.out.println(products[i].getPrice());
        }


    }
}
