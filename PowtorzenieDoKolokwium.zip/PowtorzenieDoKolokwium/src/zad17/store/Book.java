package zad17.store;

public class Book extends Product {
    @Override
    public double getPrice() {
        return 29.99;
    }
}
