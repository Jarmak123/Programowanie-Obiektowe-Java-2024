package zad17.store;

public abstract class Product {
    public abstract double getPrice();
}
