package zad33;

public class Main{
    public static void sprawdzFormatDanych(String dane) throws NiePoprawnyFormatDanychException{
        if(!dane.contains("@")){
            throw new NiePoprawnyFormatDanychException("To nie email");
        }
        else
        {
            System.out.println("Zweryfikowano");
        }
    }

    public static void main(String[] args) throws NiePoprawnyFormatDanychException{
        sprawdzFormatDanych("kurwa@HUJ.PL");
        sprawdzFormatDanych("kurwaHUJ.PL");
        sprawdzFormatDanych("kurwa@HUJ.PL");
    }
}
