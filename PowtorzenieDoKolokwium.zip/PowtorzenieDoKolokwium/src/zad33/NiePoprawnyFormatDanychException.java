package zad33;

public class NiePoprawnyFormatDanychException extends Exception {
  public NiePoprawnyFormatDanychException(String s) {
    super(s);
  }
}
