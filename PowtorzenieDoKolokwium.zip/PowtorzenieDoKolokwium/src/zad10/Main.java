package zad10;

public class Main {
    public static void main(String[] args) {
        Employee emp = new Employee("Jacek","Biuro",2000);
        Employee emp1 = new Employee("Jacek","Biuro",2000);

        Manager man = new Manager("Zdzisław","Kadry",5000,500);
        Manager man1 = new Manager("Zdzisław","Kadry",5000,500);

        Intern intera = new Intern("Alojzy", "Kierowca Kopary",10000,12);
        Intern intera1 = new Intern("Zientek", "Kierowca Kopary",10000,12);

        System.out.println(emp.equals(emp1));
        System.out.println(man.equals(man1));
        System.out.println(intera.equals(intera1));



    }
}
