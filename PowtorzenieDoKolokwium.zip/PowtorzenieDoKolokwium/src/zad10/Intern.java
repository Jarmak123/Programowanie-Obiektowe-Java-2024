package zad10;

import java.util.Objects;

public class Intern extends Employee{
    int internshipLength;

    public Intern(String name, String department, int salary, int internshipLength) {
        super(name, department, salary);
        this.internshipLength = internshipLength;
    }

    public int getInternshipLength() {
        return internshipLength;
    }

    public void setInternshipLength(int internshipLength) {
        this.internshipLength = internshipLength;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Intern intern = (Intern) o;
        return internshipLength == intern.internshipLength;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), internshipLength);
    }

    @Override
    public String toString() {
        return super.toString()+" Intern{" +
                "internshipLength=" + internshipLength +
                '}';
    }
}
