package zad14;

import java.util.Random;

public class Main {
    public static int generateInt(){
        Random rand = new Random();

        return rand.nextInt(0,2);
    }

    public static void main(String[] args) {
        System.out.println(generateInt());
    }
}
