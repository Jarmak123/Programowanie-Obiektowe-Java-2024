package zad1;

public class Dog {
    String name;
    String breed;
    int age;

    public void bark(){
        System.out.println("wof");
    }
}
