package zad24;

public class Main {
    public static void main(String[] args) {
        Teacher t1 = new Teacher("HUJ","Angielski",5);
        Teacher t2 = null;

        try{
            t2= (Teacher) t1.clone();
        }catch(CloneNotSupportedException e){
            System.out.println(e.getMessage());
        }

        System.out.println(t1);
        System.out.println(t2);

        t2.name="cwelasty";

        System.out.println(t1);
        System.out.println(t2);
    }
}
