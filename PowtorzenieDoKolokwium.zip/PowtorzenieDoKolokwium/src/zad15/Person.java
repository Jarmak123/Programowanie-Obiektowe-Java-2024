package zad15;

public class Person {
    String firstName;
    String lastName;

    public Person(String firstName, String lastName) {
        if(firstName == null || firstName.isEmpty())
        {
            firstName = "n/a";
        }
        if(lastName == null || lastName.isEmpty())
        {
            lastName = "n/a";
        }

        char[] fn = firstName.toCharArray();
        char[] ln = lastName.toCharArray();

        for(int i=0; i<firstName.length();i++)
        {
            if(!((fn[i]>=65 && fn[i]<=90) || (fn[i]>=97 && fn[i]<=122)))
            {
                firstName = "f/n";
                break;
            }
        }

        for(int i=0; i<lastName.length();i++)
        {
            if(!((ln[i]>=65 && ln[i]<=90) || (ln[i]>=97 && ln[i]<=122)))
            {
                lastName = "f/n";
                break;
            }
        }

        this.firstName = firstName;
        this.lastName = lastName;
    }

    @Override
    public String toString() {
        return  firstName + ' ' + lastName ;
    }
}
