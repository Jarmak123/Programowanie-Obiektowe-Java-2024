package zad15;

public class Main {
    public static void main(String[] args) {
        Person prs = new Person("MUSK","ELON");

        System.out.println(prs);
    }
}
