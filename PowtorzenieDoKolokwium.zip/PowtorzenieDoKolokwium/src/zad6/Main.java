package zad6;

public class Main {
    public static void main(String[] args) {
        Time t = new Time(23,15);
        Time t1 = new Time(1,50);

        System.out.println(t.hour+":"+t.minutes);

        Time tn = t.addTime(t1);

        System.out.println(tn.hour+":"+tn.minutes);

    }
}
