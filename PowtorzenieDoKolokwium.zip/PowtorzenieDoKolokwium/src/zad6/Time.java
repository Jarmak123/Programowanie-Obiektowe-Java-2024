package zad6;

public class Time {
    int hour;
    int minutes;

    public Time(int hour, int minutes) {
        this.hour = hour;
        this.minutes = minutes;
    }

    public Time addTime(Time otherTime)
    {
        int m=this.minutes+otherTime.minutes;
        int h=this.hour+otherTime.hour;
        if(m > 59)
        {
            m=m%60;
            h=h+1;
        }
        if(h >23)
        {
            h=h%24;
        }

        return new Time(h,m);
    }
}
