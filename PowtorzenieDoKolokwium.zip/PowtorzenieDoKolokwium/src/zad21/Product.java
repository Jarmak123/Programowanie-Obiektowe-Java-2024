package zad21;

import java.util.Comparator;

public class Product {
    int id;
    String name;
    double price;

    public Product(int id, String name, double price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }

    @Override
    public String toString() {
        return "Product{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", price=" + price +
                '\n';
    }
}



class priceComparator implements Comparator<Product> {

    @Override
    public int compare(Product o1, Product o2) {
        if(Double.compare(o1.price, o2.price) == 0)
        {
            return Integer.compare(o1.id, o2.id);
        }

        return Double.compare(o1.price, o2.price);

    }
}
