package zad21;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Main {
    public static void main(String[] args) {
        ArrayList<Product> prd = new ArrayList<>();

        prd.add(new Product(1,"Mydlo",20));
        prd.add(new Product(2,"Kaszanka",2));
        prd.add(new Product(3,"Klocki",80));
        prd.add(new Product(4,"Chusteczki",12));
        prd.add(new Product(5,"Keczup",2));

        System.out.println(prd);
        Collections.sort(prd, new priceComparator());
        System.out.println(prd);

    }
}
