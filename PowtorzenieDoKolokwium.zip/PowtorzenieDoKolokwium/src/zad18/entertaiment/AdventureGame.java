package zad18.entertaiment;

public class AdventureGame extends Game{
    @Override
    public double getRating() {
        return 7.3;
    }
}
