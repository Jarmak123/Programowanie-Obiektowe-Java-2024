package zad18.entertaiment;

public abstract class Game {
    public abstract double getRating();
}
