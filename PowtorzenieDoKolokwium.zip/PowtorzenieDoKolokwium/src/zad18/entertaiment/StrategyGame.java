package zad18.entertaiment;

public class StrategyGame extends Game{
    @Override
    public double getRating() {
        return 8.5;
    }
}
