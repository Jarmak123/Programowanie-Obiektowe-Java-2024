package zad18.entertaiment;

public class TestGame {
    public static void main(String[] args) {
        Game[] games = new Game[10];

        for(int i=0; i<10; i++)
        {
            if(i>4)
            {
                games[i]=new StrategyGame();
            }
            else
            {
                games[i]=new AdventureGame();
            }
        }

        for(int i=0; i<10; i++)
        {
            System.out.println(games[i].getRating());
        }


    }
}
