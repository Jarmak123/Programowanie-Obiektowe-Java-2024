package zad19;

import java.time.LocalDate;
import java.time.Year;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class Main {
    public static void main(String[] args) {
        ArrayList<Employee> emp = new ArrayList<>();

        emp.add(new Employee("Andrzej", 2019.25, LocalDate.of(1999,10,12)));
        emp.add(new Employee("Józek", 2000.25, LocalDate.of(1999,10,12)));
        emp.add(new Employee("Madga", 200.25, LocalDate.of(1999,10,12)));
        emp.add(new Employee("Jagoda", 2.25, LocalDate.of(1999,10,12)));
        emp.add(new Employee("Ryszard", 10000.25, LocalDate.of(1999,10,12)));

        System.out.println(emp);
        Collections.sort(emp);
        System.out.println(emp);
    }
}
