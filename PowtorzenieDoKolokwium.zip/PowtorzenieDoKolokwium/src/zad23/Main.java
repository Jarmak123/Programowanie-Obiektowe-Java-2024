package zad23;

import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Main {
    public static void main(String[] args) {
        ArrayList<Song> songs = new ArrayList<>();

        songs.add(new Song("Ale jazz","Sanah",250));
        songs.add(new Song("Gangnam style","PSY",250));
        songs.add(new Song("Aha","Muzyn",250));
        songs.add(new Song("Turkus","Trelek",250));
        songs.add(new Song("Srebro","Konstantin",250));

        System.out.println(songs);
        Collections.sort(songs,new DurationComparator());
        Collections.sort(songs, new ArtistTitleComparator());
        System.out.println(songs);

    }
}
