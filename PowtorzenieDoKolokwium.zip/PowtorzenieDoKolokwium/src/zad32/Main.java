package zad32;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a =0;
        int b =0;

        try{
            a = sc.nextInt();
            b = sc.nextInt();
        }catch(InputMismatchException e){
            System.out.println(e.getMessage());
        }finally{
            sc.close();
        }

        try{
            System.out.println(a/b);
        }catch(ArithmeticException e){
            System.out.println(e.getMessage());
        }
    }
}
