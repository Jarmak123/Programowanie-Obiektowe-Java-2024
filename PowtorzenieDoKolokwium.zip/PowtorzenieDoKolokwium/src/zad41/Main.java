package zad41;

public class Main {
    public static void main(String[] args) {
        Uzytkownik Jarek = new Uzytkownik(new Email());

        Jarek.powiadomOModernizacji("halo, modernizacja jest");
    }
}
