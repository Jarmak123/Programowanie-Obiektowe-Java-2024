package zad41;

public class Email implements Powiadomienie{
    @Override
    public void wyslij(String wiadomosc) {
        System.out.println("Przyszedł sms o teści: "+wiadomosc);
    }
}
