package zad41;

public interface Powiadomienie {
    public void wyslij(String wiadomosc);
}
