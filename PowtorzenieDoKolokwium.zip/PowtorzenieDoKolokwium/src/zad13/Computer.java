package zad13;

public class Computer {
    public void start(){
        System.out.println("Computer started");
    }
}
