package zad13;

public class Main {
    public static void main(String[] args) {
        Computer komp = new Computer();
        Laptop lapek = new Laptop();

        komp.start();

        lapek.start();
    }
}
