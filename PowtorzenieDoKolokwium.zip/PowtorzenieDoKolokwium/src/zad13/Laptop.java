package zad13;

public class Laptop extends Computer{
    @Override
    public void start(){
        super.start();
        System.out.println("as a laptop");
    }
}
