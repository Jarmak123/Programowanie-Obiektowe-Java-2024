package zad22;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;

public class Main {
    public static void main(String[] args) {
        ArrayList<Person> prs = new ArrayList<>();

        prs.add(new Person("Alojzy","Kleks", LocalDate.now()));
        prs.add(new Person("Eutanazja","Fąk", LocalDate.now()));
        prs.add(new Person("Siergiej","Kleks", LocalDate.now()));
        prs.add(new Person("Mandaryna","Siekierska", LocalDate.now()));
        prs.add(new Person("Alotylda","Fąk", LocalDate.now()));

        System.out.println(prs);
        Collections.sort(prs, new firstLastNameComparator());
        System.out.println(prs);
    }
}
