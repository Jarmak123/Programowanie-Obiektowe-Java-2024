package zad11;

public class Main {
    public static void main(String[] args) {
        Address adr = new Address("Piotrowskiego",12,"10-90","Alensztajn");
        Person prs = new Person("Jacek", "Kaczmarczyk",adr);

        System.out.println(adr);
        System.out.println(prs);
    }
}
