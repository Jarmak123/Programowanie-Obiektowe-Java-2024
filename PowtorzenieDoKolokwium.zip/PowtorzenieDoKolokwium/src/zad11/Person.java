package zad11;

public record Person(String firstName, String lastName, Address adres) {
}
