package zad36;

import java.util.ArrayList;
import java.util.List;

public class Counter<T>{
    private List<T> elements;

    public Counter(){
        elements = new ArrayList<>();
    }

    public void add(T element){
        elements.add(element);
    }

    public int getCount(){
        return elements.size();
    }

    public static void main(String[] args) {
        Counter<String> stringCounter = new Counter<>();
        stringCounter.add("A");
        stringCounter.add("B");
        System.out.println(stringCounter.getCount());
    }
}
