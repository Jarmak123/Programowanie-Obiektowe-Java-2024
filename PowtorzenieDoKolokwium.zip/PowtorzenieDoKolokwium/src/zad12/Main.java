package zad12;

public class Main {
    public static void main(String[] args) {
        Car samochod = new Car("Opel", "Astra",8);

        System.out.println(samochod.fuelCost(5.25,125));

    }
}
