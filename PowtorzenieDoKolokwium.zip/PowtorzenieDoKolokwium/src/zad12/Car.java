package zad12;

public record Car(String brand, String model, double fuelConsumptionPer100Km) {
    public double fuelCost(double fuelPrice, double distance){
        return fuelPrice*fuelConsumptionPer100Km*(distance/100);
    }
}
