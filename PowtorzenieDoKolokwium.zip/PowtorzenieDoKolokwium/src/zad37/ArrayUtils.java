package zad37;

public class ArrayUtils {
    public static <T extends Comparable<T>> T max(T[] array){
        if(array == null || array.length == 0)
        {
            throw new IllegalArgumentException("Tablica nie moze byc pusta");
        }

        T max = array[0];

        for(int i=0; i<array.length; i++){
            if(array[i].compareTo(max)>0)
            {
                max = array[i];
            }
        }
        return max;
    }

    public static void main(String[] args) {
        Integer[] ars = {1,2,3};

        System.out.println(max(ars));
    }
}
