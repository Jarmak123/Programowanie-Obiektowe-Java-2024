package zad25;

public class Main {
    public static void main(String[] args) {
        Engine eng1 = new Engine(250,"Benzyna",42069);
        Engine eng2 = new Engine(300,"Elektryczny",69959);

        Car samochod1 = new Car("Opel","Astra",eng1);
        Car samochod2 = new Car("Tesla","Model S",eng2);

    }
}
