public class Gracz {

    int zdrowie;
    int amunicja;
    String nazwa;

    public Gracz(){
        setDefaults();
    }

    public Gracz(int zdrowie, int amunicja, String nazwa) {
        this.zdrowie = zdrowie;
        this.amunicja = amunicja;
        this.nazwa = nazwa;
    }

    public Gracz(String nazwa) {
        new Gracz();
        this.nazwa = nazwa;
    }

    public void setZdrowie(int zdrowie){
        this.zdrowie=zdrowie;
    }

    public void setAmunicja(int amunicja){
        this.amunicja=amunicja;
    }

    public void setNazwa(String nazwa) {
        setDefaults();
        this.nazwa = nazwa;
    }

    private void setDefaults(){
        this.zdrowie = 100;
        this.amunicja = 100;
        this.nazwa = "Stefan";
    }
}
