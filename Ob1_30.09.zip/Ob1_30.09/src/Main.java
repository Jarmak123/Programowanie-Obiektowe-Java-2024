public class Main {
    static int liczbaCalkowita;
    static String napis;
    //public int a;
    //private int b;
    //protected int c;
    //(puste)
    public static void main(String[] args) {
        int liczbaCalkowita = 5;
        long liczbaCalkowitaOWiekszymZakresie;
        float liczbaZmiennoprzecinkowa = 2.0f;
        double liczbaZmiennoprzecinkowaZPodwojnaPrecyzja;
        boolean wartoscLogiczna = false;
        char pojednynczyZnak = 'g'; //pojedynczy znak
        char pojedynczyZnak1 = 65; //znak o numerze 65 w tablicy ascii
        //----------------------------------
        //String napis;
        //napis.toLowerCase();

        String napis = "Cześć!";

        Gracz gracz1 = new Gracz();
        Gracz gracz2 = new Gracz();
        gracz2.setZdrowie(80);
        gracz2.setAmunicja(50);
        gracz2.setNazwa("Lucjan");
        Gracz gracz3 = new Gracz(80,150,"Matylda");
        //gracz1.amunicja = 100;
        //gracz1.zdrowie = 100;
        //gracz1.nazwa = "Stefan";

        System.out.println("------");

        System.out.println(gracz1.amunicja);
        System.out.println(gracz2.amunicja);
        System.out.println(gracz3.amunicja);

        System.out.println("-----");


        System.out.println(napis.toLowerCase());

        System.out.println(napis);
        System.out.println(liczbaCalkowita);
        //System.out.println(liczbaZmiennoprzecinkowa); //sout
        //System.out.println();

        if(liczbaCalkowita < 3){
            System.out.println(napis.toLowerCase());
        }
        else if(liczbaZmiennoprzecinkowa < 4f){
            System.out.println(liczbaZmiennoprzecinkowa);
            System.out.println(napis.toUpperCase());
        }



        System.out.println("Hello world!");

        for(int i = 1; i <= 5; i++){
            System.out.println("i = " + i);
        }
    }
}